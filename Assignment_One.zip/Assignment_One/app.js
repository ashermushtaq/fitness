var createError = require('http-errors');
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');

var indexRouter = require('./routes/index');
var usersRouter = require('./routes/users');

var app = express();

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/', indexRouter);
app.use('/users', usersRouter);



// catch 404 and forward to error handler
// Login
app.post('/login',function(req,res){

	var username=req.body.usernameLogin; //get the username
  var password=req.body.passwordLogin; // get the password

	console.log("Username = "+username);
  console.log("Password = "+password);

	

     // connect to the db

    var mysql = require('mysql')

    var connection = mysql.createConnection({

      host     : 'localhost',
      port:3308,
      user     : 'root',

      password : '',

      database : 'justeat',

    });
    connection.connect()
    var sql = "SELECT * from users where username = '"+username+"' and password = '"+password+"' LIMIT 1;";

    console.log(sql);
    connection.query(sql, function (err, rows, fields) {

      if (err) throw err
      for(var i=0; i< rows.length; i++){

          // we can only ever send back ONE res.send(). This is the response that will be sent back to the user.

          // in this case, we are sending back the account type to the JavaScript that called this piece of codePointAt

          // to make sure that we will send them to the correct page.

           res.send(rows[i].acctype) // send it back to the caller
      }
    })
connection.end()
});

// Regester
app.post('/register',function(req,res){

	var username=req.body.usernameRegister; //get the username
  var password=req.body.passwordRegister; // get the password
  var email = req.body.email; 
  var acctype = req.body.acctype; 
  var address = req.body.address; 
	console.log("Username ="+username);
  console.log("Password ="+password);
  console.log("Email ="+email);
  console.log("Acctype ="+acctype);
  console.log("Address="+address);
});
// error handler

app.use(function(err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});



module.exports = app;